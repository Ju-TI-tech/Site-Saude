const calcular = document.getElementById('calcular');
calcular.addEventListener('click', function(){


    const altura = document.getElementById('altura').value;
    const peso = document.getElementById('peso').value;

        var valorIMC = peso.value / (altura.value * altura.value).toFixed(2);
        resultado.innerHTML = valorIMC
        
        const resultado = document.getElementById('resultado');
}
